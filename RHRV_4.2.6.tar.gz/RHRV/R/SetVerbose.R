SetVerbose <-
function(HRVData,Verbose) {
# ---------------------------
# Sets verbose mode on or off
# ---------------------------
   	HRVData$Verbose=Verbose

   	return(HRVData)
}

