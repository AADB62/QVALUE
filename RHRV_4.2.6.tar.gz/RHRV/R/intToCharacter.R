intToCharacter <- function(n) { 
#-------------------------------
# convert int to ASCII character
#-------------------------------

	rawToChar(as.raw(n)) 
}
